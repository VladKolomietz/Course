﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JobExchange.Models
{
    public class Worker
    {
        public string FullName { get; set; }
        public string Profession { get; set; }
        public string Education { get; set; }
        public string LastJob { get; set; }
        public string ReasonForLeaving { get; set; }
        public string MaritalStatus { get; set; }
        public string HousingConditions { get; set; }
        public string ContactInfo { get; set; }
        public string JobRequirements { get; set; }
        public string PhoneOrEmail { get; set; }
    }
    public class WorkerView
    {
        public string FullName { get; set; }
        public string Profession { get; set; }
        public string Education { get; set; }
        public string LastJob { get; set; }
        public string ReasonForLeaving { get; set; }
        public string MaritalStatus { get; set; }
        public string HousingConditions { get; set; }
        public string ContactInfo { get; set; }
        public string JobRequirements { get; set; }
        public string PhoneOrEmail { get; set; }
    }
}
