﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using JobExchange.Models;


namespace JobExchange.Models
{
    public class Vacancy
    {
        public string CompanyName { get; set; }
        public string Position { get; set; }
        public string WorkingConditions { get; set; }
        public string Salary { get; set; }
        public string HousingConditions { get; set; }
        public string SpecialistRequirements { get; set; }
    }
    public class VacancyView
    {
        public string CompanyName { get; set; }
        public string Position { get; set; }
        public string WorkingConditions { get; set; }
        public string Salary { get; set; }
        public string HousingConditions { get; set; }
        public string SpecialistRequirements { get; set; }
    }
}
