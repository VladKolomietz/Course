﻿namespace JobExchange.Forms
{
    partial class EmployerForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.TextBox txtCompanyName;
        private System.Windows.Forms.TextBox txtPosition;
        private System.Windows.Forms.TextBox txtWorkingConditions;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.TextBox txtHousingConditions;
        private System.Windows.Forms.TextBox txtSpecialistRequirements;

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;

        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.Label lblPosition;
        private System.Windows.Forms.Label lblWorkingConditions;
        private System.Windows.Forms.Label lblSalary;
        private System.Windows.Forms.Label lblHousingConditions;
        private System.Windows.Forms.Label lblSpecialistRequirements;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing"></param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.txtPosition = new System.Windows.Forms.TextBox();
            this.txtWorkingConditions = new System.Windows.Forms.TextBox();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.txtHousingConditions = new System.Windows.Forms.TextBox();
            this.txtSpecialistRequirements = new System.Windows.Forms.TextBox();

            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();

            this.lblCompanyName = new System.Windows.Forms.Label();
            this.lblPosition = new System.Windows.Forms.Label();
            this.lblWorkingConditions = new System.Windows.Forms.Label();
            this.lblSalary = new System.Windows.Forms.Label();
            this.lblHousingConditions = new System.Windows.Forms.Label();
            this.lblSpecialistRequirements = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Location = new System.Drawing.Point(20, 20);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(106, 17);
            this.lblCompanyName.TabIndex = 0;
            this.lblCompanyName.Text = "Назва компанії";

            // 
            // txtCompanyName
            // 
            this.txtCompanyName.Location = new System.Drawing.Point(170, 17);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(300, 22);
            this.txtCompanyName.TabIndex = 1;

            // 
            // lblPosition
            // 
            this.lblPosition.AutoSize = true;
            this.lblPosition.Location = new System.Drawing.Point(20, 60);
            this.lblPosition.Name = "lblPosition";
            this.lblPosition.Size = new System.Drawing.Size(50, 17);
            this.lblPosition.TabIndex = 2;
            this.lblPosition.Text = "Посада";

            // 
            // txtPosition
            // 
            this.txtPosition.Location = new System.Drawing.Point(170, 57);
            this.txtPosition.Name = "txtPosition";
            this.txtPosition.Size = new System.Drawing.Size(300, 22);
            this.txtPosition.TabIndex = 3;

            // 
            // lblWorkingConditions
            // 
            this.lblWorkingConditions.AutoSize = true;
            this.lblWorkingConditions.Location = new System.Drawing.Point(20, 100);
            this.lblWorkingConditions.Name = "lblWorkingConditions";
            this.lblWorkingConditions.Size = new System.Drawing.Size(104, 17);
            this.lblWorkingConditions.TabIndex = 4;
            this.lblWorkingConditions.Text = "Умови роботи";

            // 
            // txtWorkingConditions
            // 
            this.txtWorkingConditions.Location = new System.Drawing.Point(170, 97);
            this.txtWorkingConditions.Multiline = true;
            this.txtWorkingConditions.Name = "txtWorkingConditions";
            this.txtWorkingConditions.Size = new System.Drawing.Size(300, 60);
            this.txtWorkingConditions.TabIndex = 5;

            // 
            // lblSalary
            // 
            this.lblSalary.AutoSize = true;
            this.lblSalary.Location = new System.Drawing.Point(20, 170);
            this.lblSalary.Name = "lblSalary";
            this.lblSalary.Size = new System.Drawing.Size(48, 17);
            this.lblSalary.TabIndex = 6;
            this.lblSalary.Text = "Зарплата";

            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(170, 167);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(300, 22);
            this.txtSalary.TabIndex = 7;

            // 
            // lblHousingConditions
            // 
            this.lblHousingConditions.AutoSize = true;
            this.lblHousingConditions.Location = new System.Drawing.Point(20, 210);
            this.lblHousingConditions.Name = "lblHousingConditions";
            this.lblHousingConditions.Size = new System.Drawing.Size(115, 17);
            this.lblHousingConditions.TabIndex = 8;
            this.lblHousingConditions.Text = "Житлові умови";

            // 
            // txtHousingConditions
            // 
            this.txtHousingConditions.Location = new System.Drawing.Point(170, 207);
            this.txtHousingConditions.Multiline = true;
            this.txtHousingConditions.Name = "txtHousingConditions";
            this.txtHousingConditions.Size = new System.Drawing.Size(300, 60);
            this.txtHousingConditions.TabIndex = 9;

            // 
            // lblSpecialistRequirements
            // 
            this.lblSpecialistRequirements.AutoSize = true;
            this.lblSpecialistRequirements.Location = new System.Drawing.Point(20, 280);
            this.lblSpecialistRequirements.Name = "lblSpecialistRequirements";
            this.lblSpecialistRequirements.Size = new System.Drawing.Size(140, 17);
            this.lblSpecialistRequirements.TabIndex = 10;
            this.lblSpecialistRequirements.Text = "Вимоги до спеціаліста";

            // 
            // txtSpecialistRequirements
            // 
            this.txtSpecialistRequirements.Location = new System.Drawing.Point(170, 277);
            this.txtSpecialistRequirements.Multiline = true;
            this.txtSpecialistRequirements.Name = "txtSpecialistRequirements";
            this.txtSpecialistRequirements.Size = new System.Drawing.Size(300, 80);
            this.txtSpecialistRequirements.TabIndex = 11;

            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(170, 370);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Зберегти";
            this.btnSave.UseVisualStyleBackColor = true;
            // btnSave.Click += ... (додайте у EmployerForm.cs)

            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(280, 370);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Відмінити";
            this.btnCancel.UseVisualStyleBackColor = true;

            // 
            // EmployerForm
            // 
            this.ClientSize = new System.Drawing.Size(500, 420);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.txtCompanyName);
            this.Controls.Add(this.lblPosition);
            this.Controls.Add(this.txtPosition);
            this.Controls.Add(this.lblWorkingConditions);
            this.Controls.Add(this.txtWorkingConditions);
            this.Controls.Add(this.lblSalary);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.lblHousingConditions);
            this.Controls.Add(this.txtHousingConditions);
            this.Controls.Add(this.lblSpecialistRequirements);
            this.Controls.Add(this.txtSpecialistRequirements);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);

            this.Name = "EmployerForm";
            this.Text = "Додавання вакансії";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
