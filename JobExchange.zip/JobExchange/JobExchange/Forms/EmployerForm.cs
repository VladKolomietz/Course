﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JobExchange.Models;

namespace JobExchange.Forms
{
    public partial class EmployerForm : Form
    {
        public static List<Vacancy> Vacancies { get; set; } = new List<Vacancy>();
        public static List<Vacancy> ArchivedVacancies { get; set; } = new List<Vacancy>();
        static EmployerForm()
        {
            Vacancies.AddRange(new List<Vacancy>
            {
                new Vacancy {
                    CompanyName = "НКМЗ",
                    Position = "Зварювальник 4-го розряду",
                    WorkingConditions = "Повний робочий день, підприємство",
                    Salary = "28000 грн",
                    HousingConditions = "Надається гуртожиток",
                    SpecialistRequirements = "Досвід від 1 року"
                },
                new Vacancy {
                    CompanyName = "Швейна фабрика TK-Style",
                    Position = "Швачка",
                    WorkingConditions = "Повний робочий день, підприємство",
                    Salary = "17000 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Без досвіду"
                },
                new Vacancy {
                    CompanyName = "MEGOGO",
                    Position = "PPC-спеціаліст",
                    WorkingConditions = "Повний робочий день, дім",
                    Salary = "43000 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Досвід від 2 років"
                },
                new Vacancy {
                    CompanyName = "Ubisoft",
                    Position = "Тестувальник",
                    WorkingConditions = "Повний робочий день, офіс",
                    Salary = "29500 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Досвід від 1 року"
                },
                new Vacancy {
                    CompanyName = "Приватне підприємство",
                    Position = "Інженер-геодезист",
                    WorkingConditions = "Повний робочий день, підприємство",
                    Salary = "23400 грн",
                    HousingConditions = "Надається гуртожиток",
                    SpecialistRequirements = "Досвід від 3 років"
                },
                new Vacancy {
                    CompanyName = "Ресторан 'Смачні страви'",
                    Position = "Офіціант",
                    WorkingConditions = "Не повний робочий день, кафе",
                    Salary = "16000 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Без досвіду"
                },
                new Vacancy {
                    CompanyName = "АТБ",
                    Position = "Касир",
                    WorkingConditions = "Повний робочий день, магазин",
                    Salary = "15000 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Без досвіду"
                },
                new Vacancy {
                    CompanyName = "Rozetka",
                    Position = "Менеджер з продажу",
                    WorkingConditions = "Повний робочий день, дім",
                    Salary = "32500 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Досвід від 2 років"
                },
                new Vacancy {
                    CompanyName = "ЗОШ № 23",
                    Position = "Вчитель біології",
                    WorkingConditions = "Повний робочий день, школа",
                    Salary = "12500 грн",
                    HousingConditions = "Надається гуртожиток",
                    SpecialistRequirements = "Досвід від 1 року"
                },
                new Vacancy {
                    CompanyName = "ДНЗ № 3 'Сонечко'",
                    Position = "Вихователь",
                    WorkingConditions = "Повний робочий день, дитячий садок",
                    Salary = "10000 грн",
                    HousingConditions = "Не надається",
                    SpecialistRequirements = "Без досвіду"
                }
            });
        }
        public EmployerForm()
        {

            InitializeComponent();

            btnSave.Click += BtnSave_Click;
            btnCancel.Click += BtnCancel_Click;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            // Валідація
            if (string.IsNullOrWhiteSpace(txtCompanyName.Text) ||
                string.IsNullOrWhiteSpace(txtPosition.Text) ||
                string.IsNullOrWhiteSpace(txtWorkingConditions.Text) ||
                string.IsNullOrWhiteSpace(txtSalary.Text) ||
                string.IsNullOrWhiteSpace(txtHousingConditions.Text) ||
                string.IsNullOrWhiteSpace(txtSpecialistRequirements.Text)) 
            {
                MessageBox.Show("Будь ласка, заповніть обов'язкові поля: Назва компанії, посада, умови роботи, зарплата, житлові умови, вимоги до спеціаліста.",
                    "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var vacancy = new Vacancy
            {
                CompanyName = txtCompanyName.Text.Trim(),
                Position = txtPosition.Text.Trim(),
                WorkingConditions = txtWorkingConditions.Text.Trim(),
                Salary = txtSalary.Text.Trim(),
                HousingConditions = txtHousingConditions.Text.Trim(),
                SpecialistRequirements = txtSpecialistRequirements.Text.Trim()
            };

            // Додаємо нову вакансію у загальний список
            EmployerForm.Vacancies.Add(vacancy);

            MessageBox.Show("Вакансію успішно додано!", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}