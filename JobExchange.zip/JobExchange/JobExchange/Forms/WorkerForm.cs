﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JobExchange.Models;


namespace JobExchange.Forms
{
    public partial class WorkerForm : Form
    {
        public static List<Worker> Workers = new List<Worker>();
        public static List<Worker> ArchivedWorkers { get; set; } = new List<Worker>();
        static WorkerForm()
        {

            Workers.AddRange(new List<Worker>
            {

    new Worker {
        FullName = "Іваненко Олександр Максимович",
        Profession = "Менеджер по продажам",
        Education = "Вища освіта",
        LastJob = "Amazon, Менеджер по продажам",
        ReasonForLeaving = "Переїзд",
        MaritalStatus = "Одружений",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Київ",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Oleksandr_Ivanenko@gmail.com"
    },

    new Worker {
        FullName = "Шевченко Сергій Михайлович",
        Profession = "Зварювальник 5-го розряду",
        Education = "Професійно-технічна освіта",
        LastJob = "СКМЗ, Зварювальник",
        ReasonForLeaving = "Незадовільний рівень праці",
        MaritalStatus = "Одружений",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Львів",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Sergiy_Shevchenko@gmail.com"
    },

    new Worker {
        FullName = "Бондаренко Тетяна Олегівна",
        Profession = "Вихователь",
        Education = "Вища освіта",
        LastJob = "АТБ, Касир",
        ReasonForLeaving = "За сімейними обставинами",
        MaritalStatus = "Не одружена",
        HousingConditions = "Немає житла",
        ContactInfo = "м. Дніпро",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Tanya_Bondarenko@gmail.com"
    },

    new Worker {
        FullName = "Мельник Денис Андрійович",
        Profession = "PR менеджер",
        Education = "Вища освіта",
        LastJob = "Microsoft, PR менеджер",
        ReasonForLeaving = "За станом здоров'я",
        MaritalStatus = "Не одружений",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Київ",
        JobRequirements = "Графік: не повний день",
        PhoneOrEmail = "Denis_Melnik@gmail.com"
    },

    new Worker {
        FullName = "Кравченко Марія Семенівна",
        Profession = "Бариста",
        Education = "Базова середня освіта",
        LastJob = "Кафе 'Смачний аромат', Менеджер",
        ReasonForLeaving = "За згодою сторін",
        MaritalStatus = "Одружена",
        HousingConditions = "Немає житла",
        ContactInfo = "м. Харків",
        JobRequirements = "Графік: не повний день",
        PhoneOrEmail = "Kravchenko_Mariya@gmail.com"
    },

    new Worker {
        FullName = "Ковальчук Дмитро Романович",
        Profession = "Слюсар",
        Education = "Професійно-технічна освіта",
        LastJob = "НКМЗ, Менеджер",
        ReasonForLeaving = "Оптимізація",
        MaritalStatus = "Одружений",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Краматорськ",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Kovalchuk_Dima@gmail.com"
    },

    new Worker {
        FullName = "Бойко Наталія Олександрівна",
        Profession = "Тестувальник",
        Education = "Вища освіта",
        LastJob = "Rockstar games, Тестувальник",
        ReasonForLeaving = "За згодою сторін",
        MaritalStatus = "Одружена",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Київ",
        JobRequirements = "Графік: не повний день",
        PhoneOrEmail = "Bouko_Nataliya@gmail.com"
    },

    new Worker {
        FullName = "Ткаченко Юрій Сергійович",
        Profession = "Інженер-електрик",
        Education = "Вища освіта",
        LastJob = "ТОВ «Комбікорм — Полтава», Інженер-електрик",
        ReasonForLeaving = "Незадовільні умови праці",
        MaritalStatus = "Не одружений",
        HousingConditions = "Немає житла",
        ContactInfo = "м. Полтава",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Tkachenko_Yriy@gmail.com"
    },

    new Worker {
        FullName = "Лисенко Валентина Іванівна",
        Profession = "Касир",
        Education = "Базова середня освіта",
        LastJob = "ДНЗ № 25, Вихователь",
        ReasonForLeaving = "Низька заробітня плата",
        MaritalStatus = "Одружена",
        HousingConditions = "Орендована квартира",
        ContactInfo = "м. Житомир",
        JobRequirements = "Графік: повний день",
        PhoneOrEmail = "Lisenko_Valentina@email.com"
    },

    new Worker {
        FullName = "Шевчук Микита Олександрович",
        Profession = "Інженер-геодезист",
        Education = "Вища освіта",
        LastJob = "ТОВ Укргруппроект, Інженер",
        ReasonForLeaving = "Оптимізація",
        MaritalStatus = "Не одружений",
        HousingConditions = "Немає житла",
        ContactInfo = "м. Львів",
        JobRequirements = "Графік: не повний день",
        PhoneOrEmail = "Shevchuk_Mukuta@gmail.com"
    }
            });
        }

        public WorkerForm()
        {
            InitializeComponent();
            btnSave.Click += btnSave_Click;
            btnCancel.Click += btnCancel_Click;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text) ||
                string.IsNullOrWhiteSpace(txtProfession.Text) ||
                string.IsNullOrWhiteSpace(txtEducation.Text) ||
                string.IsNullOrWhiteSpace(txtLastJob.Text) ||
                string.IsNullOrWhiteSpace(txtReasonForLeaving.Text) ||
                string.IsNullOrWhiteSpace(txtMaritalStatus.Text) ||
                string.IsNullOrWhiteSpace(txtHousingConditions.Text) ||
                string.IsNullOrWhiteSpace(txtContactInfo.Text) ||
                string.IsNullOrWhiteSpace(txtJobRequirements.Text) ||
                string.IsNullOrWhiteSpace(txtPhoneOrEmail.Text))
            {
                MessageBox.Show("Будь ласка, заповніть усі поля.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var worker = new Worker
            {
                FullName = txtFullName.Text.Trim(),
                Profession = txtProfession.Text.Trim(),
                Education = txtEducation.Text.Trim(),
                LastJob = txtLastJob.Text.Trim(),
                ReasonForLeaving = txtReasonForLeaving.Text.Trim(),
                MaritalStatus = txtMaritalStatus.Text.Trim(),
                HousingConditions = txtHousingConditions.Text.Trim(),
                ContactInfo = txtContactInfo.Text.Trim(),
                JobRequirements = txtJobRequirements.Text.Trim(),
                PhoneOrEmail = txtPhoneOrEmail.Text.Trim()  
            };

            WorkerForm.Workers.Add(worker);

            MessageBox.Show("Дані робітника успішно збережено.", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}