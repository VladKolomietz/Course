﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using JobExchange.Models;

namespace JobExchange.Forms
{
    public partial class WorkersListForm : Form
    {
        private BindingSource bindingSource = new BindingSource();
        private bool sortAscending = true;
        public WorkersListForm()
        {
            InitializeComponent();
            btnSearch.Click += (s, e) => FilterTable();
            btnReset.Click += (s, e) => ResetSearch();
            dgv.ColumnHeaderMouseClick += Dgv_ColumnHeaderMouseClick;
            LoadDeleteWorkerComboBox();
            btnDeletePermanently.Click += btnDelete_Click;

            cmbDeleteWorker.SelectedIndexChanged += cmbWorkers_SelectedIndexChanged;

            LoadSearchColumns();
            LoadData();
        }

        private void LoadData()
        {
            var data = WorkerForm.Workers.Select(w => new WorkerView
            {
                FullName = w.FullName,
                Profession = w.Profession,
                Education = w.Education,
                LastJob = w.LastJob,
                ReasonForLeaving = w.ReasonForLeaving,
                MaritalStatus = w.MaritalStatus,
                HousingConditions = w.HousingConditions,
                ContactInfo = w.ContactInfo,
                JobRequirements = w.JobRequirements,
                PhoneOrEmail = w.PhoneOrEmail
            }).ToList();

            bindingSource.DataSource = data;
            dgv.DataSource = bindingSource;

            // Перейменування стовпців
            RenameColumns();
        }

        private void RenameColumns()
        {
            dgv.Columns["FullName"].HeaderText = "ПІБ";
            dgv.Columns["Profession"].HeaderText = "Професія";
            dgv.Columns["Education"].HeaderText = "Освіта";
            dgv.Columns["LastJob"].HeaderText = "Останнє місце роботи";
            dgv.Columns["ReasonForLeaving"].HeaderText = "Причина звільнення";
            dgv.Columns["MaritalStatus"].HeaderText = "Сімейний стан";
            dgv.Columns["HousingConditions"].HeaderText = "Житлові умови";
            dgv.Columns["ContactInfo"].HeaderText = "Місце проживання";
            dgv.Columns["JobRequirements"].HeaderText = "Бажані умови праці";
            dgv.Columns["PhoneOrEmail"].HeaderText = "Телефон / Email";
        }

        private void LoadSearchColumns()
        {
            var columns = new List<KeyValuePair<string, string>>
    {
        new KeyValuePair<string, string>("", "Усі поля"),
        new KeyValuePair<string, string>("FullName", "ПІБ"),
        new KeyValuePair<string, string>("Profession", "Професія"),
        new KeyValuePair<string, string>("Education", "Освіта"),
        new KeyValuePair<string, string>("LastJob", "Останнє місце роботи"),
        new KeyValuePair<string, string>("ReasonForLeaving", "Причина звільнення"),
        new KeyValuePair<string, string>("MaritalStatus", "Сімейний стан"),
        new KeyValuePair<string, string>("HousingConditions", "Житлові умови"),
        new KeyValuePair<string, string>("ContactInfo", "Місце проживання"),
        new KeyValuePair<string, string>("JobRequirements", "Бажані умови праці"),
        new KeyValuePair<string, string>("PhoneOrEmail", "Телефон / Email")
    };

            cmbSearchColumn.DataSource = columns;
            cmbSearchColumn.DisplayMember = "Value"; 
            cmbSearchColumn.ValueMember = "Key";     
        }
        private void FilterTable()
        {
            string query = txtSearch.Text.ToLower();
            string selectedColumn = cmbSearchColumn.SelectedValue?.ToString();

            var filtered = WorkerForm.Workers.Where(w =>
            {
                if (string.IsNullOrEmpty(selectedColumn))
                {
                    // Пошук по всіх полях
                    return w.FullName.ToLower().Contains(query) ||
                           w.Profession.ToLower().Contains(query) ||
                           w.Education.ToLower().Contains(query) ||
                           w.LastJob.ToLower().Contains(query) ||
                           w.ReasonForLeaving.ToLower().Contains(query) ||
                           w.MaritalStatus.ToLower().Contains(query) ||
                           w.HousingConditions.ToLower().Contains(query) ||
                           w.ContactInfo.ToLower().Contains(query) ||
                           w.JobRequirements.ToLower().Contains(query) ||
                           w.PhoneOrEmail.ToLower().Contains(query);
                }
                else
                {
                    var prop = w.GetType().GetProperty(selectedColumn);
                    if (prop != null)
                    {
                        var value = prop.GetValue(w)?.ToString()?.ToLower();
                        return value != null && value.Contains(query);
                    }
                    return false;
                }
            }).ToList();

            bindingSource.DataSource = filtered;
        }

        private void ResetSearch()
        {
            txtSearch.Text = "";
            LoadData();
        }

        private void Dgv_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string columnName = dgv.Columns[e.ColumnIndex].DataPropertyName;
            var currentData = bindingSource.DataSource as List<WorkerView>;

            if (currentData == null || currentData.Count == 0)
                return;

            currentData = sortAscending
                ? currentData.OrderBy(x => x.GetType().GetProperty(columnName).GetValue(x)).ToList()
                : currentData.OrderByDescending(x => x.GetType().GetProperty(columnName).GetValue(x)).ToList();

            sortAscending = !sortAscending;
            bindingSource.DataSource = currentData;
            dgv.DataSource = bindingSource;

            RenameColumns();
        }

        private void LoadDeleteWorkerComboBox()
        {
            cmbWorkers.DataSource = null;

            var items = WorkerForm.Workers
                .Concat(WorkerForm.ArchivedWorkers)
                .Select(w => new
                {
                    Display = $"{w.FullName} ({w.PhoneOrEmail})",
                    Worker = w
                })
                .ToList();

            cmbWorkers.DataSource = items;
            cmbWorkers.DisplayMember = "Display";
            cmbWorkers.ValueMember = "Worker";
        }
        private void cmbWorkers_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selected = cmbWorkers.SelectedItem;
            if (selected != null)
            {
                var worker = selected.GetType().GetProperty("Worker")?.GetValue(selected) as Worker;
                if (worker != null)
                {
                    Console.WriteLine($"Обрано працівника: {worker.FullName}");
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (cmbWorkers.SelectedItem is null)
            {
                MessageBox.Show("Оберіть працівника для видалення.");
                return;
            }

            var selectedWorker = ((dynamic)cmbWorkers.SelectedItem).Worker;

            if (WorkerForm.ArchivedWorkers.Contains(selectedWorker))
            {
                MessageBox.Show("Неможливо видалити працівника, який вже знаходиться в архіві.");
                return;
            }

            // Видалення з усіх можливих списків
            WorkerForm.Workers.Remove(selectedWorker);

            MessageBox.Show("Працівника видалено остаточно.");

            LoadData(); // оновлення таблиці
            LoadDeleteWorkerComboBox(); // оновлення списку для видалення
        }
    }
}