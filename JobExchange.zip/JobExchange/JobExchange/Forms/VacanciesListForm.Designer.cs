﻿namespace JobExchange.Forms
{
    partial class VacanciesListForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ComboBox cmbWorkers;
        private System.Windows.Forms.ComboBox cmbVacancies;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ComboBox cmbArchivedWorkers;
        private System.Windows.Forms.ComboBox cmbArchivedVacancies;
        private System.Windows.Forms.Button btnRestore;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgv = new DataGridView();
            txtSearch = new TextBox();
            btnSearch = new Button();
            btnReset = new Button();
            cmbWorkers = new ComboBox();
            cmbVacancies = new ComboBox();
            btnDelete = new Button();
            cmbArchivedWorkers = new ComboBox();
            cmbArchivedVacancies = new ComboBox();
            btnRestore = new Button();
            cmbSearchColumn = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            SuspendLayout();
            // 
            // dgv
            // 
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.Location = new Point(9, 89);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dgv.Size = new Size(1160, 519);
            dgv.TabIndex = 0;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(10, 10);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(600, 23);
            txtSearch.TabIndex = 1;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(620, 10);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Пошук";
            btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(710, 10);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(75, 23);
            btnReset.TabIndex = 3;
            btnReset.Text = "Відмінити";
            btnReset.UseVisualStyleBackColor = true;
            // 
            // cmbWorkers
            // 
            cmbWorkers.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbWorkers.Location = new Point(9, 643);
            cmbWorkers.Name = "cmbWorkers";
            cmbWorkers.Size = new Size(400, 23);
            cmbWorkers.TabIndex = 4;
            // 
            // cmbVacancies
            // 
            cmbVacancies.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbVacancies.Location = new Point(419, 643);
            cmbVacancies.Name = "cmbVacancies";
            cmbVacancies.Size = new Size(300, 23);
            cmbVacancies.TabIndex = 5;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(729, 643);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(140, 23);
            btnDelete.TabIndex = 6;
            btnDelete.Text = "Помістити до архіву";
            btnDelete.UseVisualStyleBackColor = true;
            // 
            // cmbArchivedWorkers
            // 
            cmbArchivedWorkers.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbArchivedWorkers.Location = new Point(9, 672);
            cmbArchivedWorkers.Name = "cmbArchivedWorkers";
            cmbArchivedWorkers.Size = new Size(400, 23);
            cmbArchivedWorkers.TabIndex = 7;
            // 
            // cmbArchivedVacancies
            // 
            cmbArchivedVacancies.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbArchivedVacancies.Location = new Point(419, 672);
            cmbArchivedVacancies.Name = "cmbArchivedVacancies";
            cmbArchivedVacancies.Size = new Size(300, 23);
            cmbArchivedVacancies.TabIndex = 8;
            // 
            // btnRestore
            // 
            btnRestore.Location = new Point(729, 672);
            btnRestore.Name = "btnRestore";
            btnRestore.Size = new Size(140, 23);
            btnRestore.TabIndex = 9;
            btnRestore.Text = "Повернути з архіву";
            btnRestore.UseVisualStyleBackColor = true;
            // 
            // cmbSearchColumn
            // 
            cmbSearchColumn.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSearchColumn.Location = new Point(9, 39);
            cmbSearchColumn.Name = "cmbSearchColumn";
            cmbSearchColumn.Size = new Size(400, 23);
            cmbSearchColumn.TabIndex = 10;
            // 
            // VacanciesListForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1201, 707);
            Controls.Add(cmbSearchColumn);
            Controls.Add(btnRestore);
            Controls.Add(cmbArchivedVacancies);
            Controls.Add(cmbArchivedWorkers);
            Controls.Add(dgv);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Controls.Add(btnReset);
            Controls.Add(cmbWorkers);
            Controls.Add(cmbVacancies);
            Controls.Add(btnDelete);
            Name = "VacanciesListForm";
            Text = "Список вакансій";
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
        private ComboBox cmbSearchColumn;
    }
}
