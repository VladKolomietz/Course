﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using JobExchange.Models;

namespace JobExchange.Forms
{
    public partial class VacanciesListForm : Form
    {
        private BindingSource bindingSource = new BindingSource();
        private bool sortAscending = true;
 

        public VacanciesListForm()
        {
            InitializeComponent();
            dgv.ColumnHeaderMouseClick += Dgv_ColumnHeaderMouseClick;
            btnSearch.Click += (s, e) => FilterTable();
            btnReset.Click += (s, e) => ResetSearch();
            btnDelete.Click += BtnDelete_Click;
            btnRestore.Click += BtnRestore_Click;

            LoadData();
            LoadComboBoxes();
            LoadSearchColumns();
            LoadArchivedComboBoxes();
        }

        private void LoadData()
        {
            var data = EmployerForm.Vacancies.Select(v => new VacancyView
            {
                CompanyName = v.CompanyName,
                Position = v.Position,
                WorkingConditions = v.WorkingConditions,
                Salary = v.Salary,
                HousingConditions = v.HousingConditions,
                SpecialistRequirements = v.SpecialistRequirements
            }).ToList();

            bindingSource.DataSource = data;
            dgv.DataSource = bindingSource;
            RenameColumns();
        }

        private void RenameColumns()
        {
            dgv.Columns["CompanyName"].HeaderText = "Назва компанії";
            dgv.Columns["Position"].HeaderText = "Посада";
            dgv.Columns["WorkingConditions"].HeaderText = "Умови праці";
            dgv.Columns["Salary"].HeaderText = "Заробітна плата";
            dgv.Columns["HousingConditions"].HeaderText = "Умови проживання";
            dgv.Columns["SpecialistRequirements"].HeaderText = "Вимоги до спеціаліста";
        }
        private void LoadSearchColumns()
        {
            var columns = new List<KeyValuePair<string, string>>
    {
        new KeyValuePair<string, string>("", "Усі поля"),
        new KeyValuePair<string, string>("CompanyName", "Назва компанії"),
        new KeyValuePair<string, string>("Position", "Посада"),
        new KeyValuePair<string, string>("WorkingConditions", "Умови праці"),
        new KeyValuePair<string, string>("Salary", "Зарплата"),
        new KeyValuePair<string, string>("HousingConditions", "Житлові умови"),
        new KeyValuePair<string, string>("SpecialistRequirements", "Вимоги до спеціаліста")
    };

            cmbSearchColumn.DataSource = columns;
            cmbSearchColumn.DisplayMember = "Value";
            cmbSearchColumn.ValueMember = "Key";
        }

        private void LoadComboBoxes()
        {
            // Workers ComboBox
            cmbWorkers.DataSource = WorkerForm.Workers
                .Select(w => new
                {
                    Display = $"{w.FullName} ({w.PhoneOrEmail})",
                    Worker = w
                })
                .ToList();

            cmbWorkers.DisplayMember = "Display";
            cmbWorkers.ValueMember = "Worker";

            // Vacancies ComboBox
            cmbVacancies.DataSource = EmployerForm.Vacancies
                .Select(v => new
                {
                    Display = $"{v.CompanyName} ({v.Position})",
                    Vacancy = v
                })
                .ToList();

            cmbVacancies.DisplayMember = "Display";
            cmbVacancies.ValueMember = "Vacancy";
        }

        private void FilterTable()
        {
            string query = txtSearch.Text.ToLower();
            string selectedColumn = cmbSearchColumn.SelectedValue?.ToString();

            var filtered = EmployerForm.Vacancies.Where(v =>
            {
                if (string.IsNullOrEmpty(selectedColumn))
                {
                    return v.CompanyName.ToLower().Contains(query) ||
                           v.Position.ToLower().Contains(query) ||
                           v.WorkingConditions.ToLower().Contains(query) ||
                           v.Salary.ToLower().Contains(query) ||
                           v.HousingConditions.ToLower().Contains(query) ||
                           v.SpecialistRequirements.ToLower().Contains(query);
                }
                else
                {
                    var prop = v.GetType().GetProperty(selectedColumn);
                    if (prop != null)
                    {
                        var value = prop.GetValue(v)?.ToString()?.ToLower();
                        return value != null && value.Contains(query);
                    }
                    return false;
                }
            }).ToList();

            dgv.DataSource = filtered;
        }

        private void ResetSearch()
        {
            txtSearch.Text = "";
            LoadData();
        }

        private void Dgv_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            string columnName = dgv.Columns[e.ColumnIndex].DataPropertyName;
            var currentData = bindingSource.DataSource as List<VacancyView>;

            if (currentData == null || currentData.Count == 0)
                return;

            if (columnName == "Salary")
            {
                currentData = sortAscending
                    ? currentData.OrderBy(v => ParseSalary(v.Salary)).ToList()
                    : currentData.OrderByDescending(v => ParseSalary(v.Salary)).ToList();
            }
            else
            {
                currentData = sortAscending
                    ? currentData.OrderBy(x => x.GetType().GetProperty(columnName).GetValue(x)).ToList()
                    : currentData.OrderByDescending(x => x.GetType().GetProperty(columnName).GetValue(x)).ToList();
            }

            sortAscending = !sortAscending;
            bindingSource.DataSource = currentData;
            dgv.DataSource = bindingSource;
        }

        private int ParseSalary(string salary)
        {
            if (string.IsNullOrWhiteSpace(salary))
                return 0;

            var digits = new string(salary.Where(char.IsDigit).ToArray());
            return int.TryParse(digits, out int result) ? result : 0;
        }
        private void LoadArchivedComboBoxes()
        {
            cmbArchivedWorkers.DataSource = null;
            cmbArchivedVacancies.DataSource = null;
            cmbArchivedWorkers.Refresh();
            cmbArchivedVacancies.Refresh();

            var archivedWorkers = WorkerForm.ArchivedWorkers
                .Select(w => new
                {
                    Display = $"{w.FullName} ({w.PhoneOrEmail})",
                    Worker = w
                })
                .ToList();

            cmbArchivedWorkers.DataSource = archivedWorkers;
            cmbArchivedWorkers.DisplayMember = "Display";
            cmbArchivedWorkers.ValueMember = "Worker";

            var archivedVacancies = EmployerForm.ArchivedVacancies
                .Select(v => new
                {
                    Display = $"{v.CompanyName} ({v.Position})",
                    Vacancy = v
                })
                .ToList();

            cmbArchivedVacancies.DataSource = archivedVacancies;
            cmbArchivedVacancies.DisplayMember = "Display";
            cmbArchivedVacancies.ValueMember = "Vacancy";
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            var selectedWorker = cmbWorkers.SelectedItem?.GetType().GetProperty("Worker")?.GetValue(cmbWorkers.SelectedItem) as Worker;
            var selectedVacancy = cmbVacancies.SelectedItem?.GetType().GetProperty("Vacancy")?.GetValue(cmbVacancies.SelectedItem) as Vacancy;

            if (selectedWorker != null && selectedVacancy != null)
            {
                // Переміщуємо працівника в архів
                WorkerForm.Workers.Remove(selectedWorker);
                WorkerForm.ArchivedWorkers.Add(selectedWorker);

                // Переміщуємо вакансію в архів
                EmployerForm.Vacancies.Remove(selectedVacancy);
                EmployerForm.ArchivedVacancies.Add(selectedVacancy);

                MessageBox.Show("Працівника та вакансію відкладено в архів.", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadData();
                LoadComboBoxes();
                LoadArchivedComboBoxes();
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть і працівника, і вакансію.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void BtnRestore_Click(object sender, EventArgs e)
        {
            var selectedWorker = cmbArchivedWorkers.SelectedItem?.GetType().GetProperty("Worker")?.GetValue(cmbArchivedWorkers.SelectedItem) as Worker;
            var selectedVacancy = cmbArchivedVacancies.SelectedItem?.GetType().GetProperty("Vacancy")?.GetValue(cmbArchivedVacancies.SelectedItem) as Vacancy;

            if (selectedWorker != null && selectedVacancy != null)
            {
                WorkerForm.ArchivedWorkers.Remove(selectedWorker);
                WorkerForm.Workers.Add(selectedWorker);

                EmployerForm.ArchivedVacancies.Remove(selectedVacancy);
                EmployerForm.Vacancies.Add(selectedVacancy);

                MessageBox.Show("Працівника та вакансію повернено з архіву.", "Успіх", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadData();
                LoadComboBoxes();
                LoadArchivedComboBoxes();
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть і працівника, і вакансію з архіву.", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
