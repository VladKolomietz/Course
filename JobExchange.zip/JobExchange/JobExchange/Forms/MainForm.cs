﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JobExchange.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            btnOpenEmployerForm.Click += BtnOpenEmployerForm_Click;
            btnOpenWorkerForm.Click += BtnOpenWorkerForm_Click;
            btnOpenVacanciesListForm.Click += BtnOpenVacanciesListForm_Click;
            btnOpenWorkerListForm.Click += BtnOpenWorkerListForm_Click;
        }

        private void BtnOpenEmployerForm_Click(object sender, EventArgs e)
        {
            var form = new EmployerForm();
            form.ShowDialog();
        }

        private void BtnOpenWorkerForm_Click(object sender, EventArgs e)
        {
            var form = new WorkerForm();
            form.ShowDialog();
        }

        private void BtnOpenVacanciesListForm_Click(object sender, EventArgs e)
        {
            var form = new VacanciesListForm();
            form.ShowDialog();
        }

        private void BtnOpenWorkerListForm_Click(object sender, EventArgs e)
        {
            var form = new WorkersListForm();
            form.ShowDialog();
        }
    }
}
