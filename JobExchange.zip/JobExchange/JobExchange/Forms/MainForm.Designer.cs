﻿namespace JobExchange.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnOpenEmployerForm;
        private System.Windows.Forms.Button btnOpenWorkerForm;
        private System.Windows.Forms.Button btnOpenVacanciesListForm;
        private System.Windows.Forms.Button btnOpenWorkerListForm;  // Додана кнопка

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnOpenEmployerForm = new Button();
            btnOpenWorkerForm = new Button();
            btnOpenVacanciesListForm = new Button();
            btnOpenWorkerListForm = new Button();
            SuspendLayout();
            // 
            // btnOpenEmployerForm
            // 
            btnOpenEmployerForm.Location = new Point(232, 108);
            btnOpenEmployerForm.Name = "btnOpenEmployerForm";
            btnOpenEmployerForm.Size = new Size(219, 40);
            btnOpenEmployerForm.TabIndex = 0;
            btnOpenEmployerForm.Text = "Додати вакансію як роботодавець";
            btnOpenEmployerForm.UseVisualStyleBackColor = true;
            // 
            // btnOpenWorkerForm
            // 
            btnOpenWorkerForm.Location = new Point(232, 166);
            btnOpenWorkerForm.Name = "btnOpenWorkerForm";
            btnOpenWorkerForm.Size = new Size(219, 40);
            btnOpenWorkerForm.TabIndex = 1;
            btnOpenWorkerForm.Text = "Додати анкету як працівник";
            btnOpenWorkerForm.UseVisualStyleBackColor = true;
            // 
            // btnOpenVacanciesListForm
            // 
            btnOpenVacanciesListForm.Location = new Point(232, 225);
            btnOpenVacanciesListForm.Name = "btnOpenVacanciesListForm";
            btnOpenVacanciesListForm.Size = new Size(219, 40);
            btnOpenVacanciesListForm.TabIndex = 2;
            btnOpenVacanciesListForm.Text = "Список вакансій";
            btnOpenVacanciesListForm.UseVisualStyleBackColor = true;
            // 
            // btnOpenWorkerListForm
            // 
            btnOpenWorkerListForm.Location = new Point(232, 281);
            btnOpenWorkerListForm.Name = "btnOpenWorkerListForm";
            btnOpenWorkerListForm.Size = new Size(219, 40);
            btnOpenWorkerListForm.TabIndex = 3;
            btnOpenWorkerListForm.Text = "Список працівників";
            btnOpenWorkerListForm.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            ClientSize = new Size(727, 465);
            Controls.Add(btnOpenWorkerListForm);
            Controls.Add(btnOpenVacanciesListForm);
            Controls.Add(btnOpenWorkerForm);
            Controls.Add(btnOpenEmployerForm);
            Name = "MainForm";
            Text = "Головна";
            ResumeLayout(false);

        }
    }
}
