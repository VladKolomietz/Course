﻿namespace JobExchange.Forms
{
    partial class WorkersListForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ComboBox cmbDeleteWorker;
        private System.Windows.Forms.Button btnDeletePermanently;
        private System.Windows.Forms.ComboBox cmbArchivedWorkers;



        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            dgv = new DataGridView();
            txtSearch = new TextBox();
            btnSearch = new Button();
            btnReset = new Button();
            cmbWorkers = new ComboBox();
            btnDelete = new Button();
            cmbDeleteWorker = new ComboBox();
            btnDeletePermanently = new Button();
            cmbSearchColumn = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)dgv).BeginInit();
            SuspendLayout();
            // 
            // dgv
            // 
            dgv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            dgv.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgv.DefaultCellStyle = dataGridViewCellStyle2;
            dgv.Location = new Point(10, 68);
            dgv.Name = "dgv";
            dgv.ReadOnly = true;
            dgv.Size = new Size(1182, 555);
            dgv.TabIndex = 4;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(10, 10);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(600, 23);
            txtSearch.TabIndex = 0;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(620, 10);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(80, 23);
            btnSearch.TabIndex = 5;
            btnSearch.Text = "Пошук";
            btnSearch.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            btnReset.Location = new Point(710, 10);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(80, 23);
            btnReset.TabIndex = 6;
            btnReset.Text = "Відмінити";
            btnReset.UseVisualStyleBackColor = true;
            // 
            // cmbWorkers
            // 
            cmbWorkers.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbWorkers.Location = new Point(10, 649);
            cmbWorkers.Name = "cmbWorkers";
            cmbWorkers.Size = new Size(400, 23);
            cmbWorkers.TabIndex = 7;
            cmbWorkers.SelectedIndexChanged += cmbWorkers_SelectedIndexChanged;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(416, 649);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(140, 23);
            btnDelete.TabIndex = 8;
            btnDelete.Text = "Відмова від послуг";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // cmbDeleteWorker
            // 
            cmbDeleteWorker.Location = new Point(0, 0);
            cmbDeleteWorker.Name = "cmbDeleteWorker";
            cmbDeleteWorker.Size = new Size(121, 23);
            cmbDeleteWorker.TabIndex = 0;
            // 
            // btnDeletePermanently
            // 
            btnDeletePermanently.Location = new Point(0, 0);
            btnDeletePermanently.Name = "btnDeletePermanently";
            btnDeletePermanently.Size = new Size(75, 23);
            btnDeletePermanently.TabIndex = 0;
            // 
            // cmbSearchColumn
            // 
            cmbSearchColumn.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbSearchColumn.Location = new Point(10, 39);
            cmbSearchColumn.Name = "cmbSearchColumn";
            cmbSearchColumn.Size = new Size(400, 23);
            cmbSearchColumn.TabIndex = 9;
            // 
            // WorkersListForm
            // 
            ClientSize = new Size(1204, 693);
            Controls.Add(cmbSearchColumn);
            Controls.Add(btnDelete);
            Controls.Add(cmbWorkers);
            Controls.Add(dgv);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Controls.Add(btnReset);
            Name = "WorkersListForm";
            Text = "Список працівників";
            ((System.ComponentModel.ISupportInitialize)dgv).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }
        private ComboBox cmbWorkers;
        private Button btnDelete;
        private ComboBox cmbSearchColumn;
    }
}