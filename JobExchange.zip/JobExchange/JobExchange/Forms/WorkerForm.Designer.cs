﻿namespace JobExchange.Forms
{
    partial class WorkerForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.Label lblProfession;
        private System.Windows.Forms.Label lblEducation;
        private System.Windows.Forms.Label lblLastJob;
        private System.Windows.Forms.Label lblReasonForLeaving;
        private System.Windows.Forms.Label lblMaritalStatus;
        private System.Windows.Forms.Label lblHousingConditions;
        private System.Windows.Forms.Label lblContactInfo;
        private System.Windows.Forms.Label lblJobRequirements;
        private System.Windows.Forms.Label lblPhoneOrEmail;

        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.TextBox txtProfession;
        private System.Windows.Forms.TextBox txtEducation;
        private System.Windows.Forms.TextBox txtLastJob;
        private System.Windows.Forms.TextBox txtReasonForLeaving;
        private System.Windows.Forms.TextBox txtMaritalStatus;
        private System.Windows.Forms.TextBox txtHousingConditions;
        private System.Windows.Forms.TextBox txtContactInfo;
        private System.Windows.Forms.TextBox txtJobRequirements;
        private System.Windows.Forms.TextBox txtPhoneOrEmail;

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblFullName = new Label();
            lblProfession = new Label();
            lblEducation = new Label();
            lblLastJob = new Label();
            lblReasonForLeaving = new Label();
            lblMaritalStatus = new Label();
            lblHousingConditions = new Label();
            lblContactInfo = new Label();
            lblJobRequirements = new Label();
            lblPhoneOrEmail = new Label();
            txtFullName = new TextBox();
            txtProfession = new TextBox();
            txtEducation = new TextBox();
            txtLastJob = new TextBox();
            txtReasonForLeaving = new TextBox();
            txtMaritalStatus = new TextBox();
            txtHousingConditions = new TextBox();
            txtContactInfo = new TextBox();
            txtJobRequirements = new TextBox();
            txtPhoneOrEmail = new TextBox();
            btnSave = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Location = new Point(20, 20);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(69, 15);
            lblFullName.TabIndex = 0;
            lblFullName.Text = "Повне ім'я:";
            // 
            // lblProfession
            // 
            lblProfession.AutoSize = true;
            lblProfession.Location = new Point(20, 55);
            lblProfession.Name = "lblProfession";
            lblProfession.Size = new Size(63, 15);
            lblProfession.TabIndex = 2;
            lblProfession.Text = "Професія:";
            // 
            // lblEducation
            // 
            lblEducation.AutoSize = true;
            lblEducation.Location = new Point(20, 90);
            lblEducation.Name = "lblEducation";
            lblEducation.Size = new Size(45, 15);
            lblEducation.TabIndex = 4;
            lblEducation.Text = "Освіта:";
            // 
            // lblLastJob
            // 
            lblLastJob.AutoSize = true;
            lblLastJob.Location = new Point(20, 125);
            lblLastJob.Name = "lblLastJob";
            lblLastJob.Size = new Size(133, 15);
            lblLastJob.TabIndex = 6;
            lblLastJob.Text = "Останнє місце роботи:";
            // 
            // lblReasonForLeaving
            // 
            lblReasonForLeaving.AutoSize = true;
            lblReasonForLeaving.Location = new Point(20, 160);
            lblReasonForLeaving.Name = "lblReasonForLeaving";
            lblReasonForLeaving.Size = new Size(123, 15);
            lblReasonForLeaving.TabIndex = 8;
            lblReasonForLeaving.Text = "Причина звільнення:";
            // 
            // lblMaritalStatus
            // 
            lblMaritalStatus.AutoSize = true;
            lblMaritalStatus.Location = new Point(20, 195);
            lblMaritalStatus.Name = "lblMaritalStatus";
            lblMaritalStatus.Size = new Size(91, 15);
            lblMaritalStatus.TabIndex = 10;
            lblMaritalStatus.Text = "Сімейний стан:";
            // 
            // lblHousingConditions
            // 
            lblHousingConditions.AutoSize = true;
            lblHousingConditions.Location = new Point(20, 230);
            lblHousingConditions.Name = "lblHousingConditions";
            lblHousingConditions.Size = new Size(94, 15);
            lblHousingConditions.TabIndex = 12;
            lblHousingConditions.Text = "Житлові умови:";
            // 
            // lblContactInfo
            // 
            lblContactInfo.AutoSize = true;
            lblContactInfo.Location = new Point(20, 265);
            lblContactInfo.Name = "lblContactInfo";
            lblContactInfo.Size = new Size(115, 15);
            lblContactInfo.TabIndex = 14;
            lblContactInfo.Text = "Місце проживання:";
            // 
            // lblJobRequirements
            // 
            lblJobRequirements.AutoSize = true;
            lblJobRequirements.Location = new Point(20, 300);
            lblJobRequirements.Name = "lblJobRequirements";
            lblJobRequirements.Size = new Size(111, 15);
            lblJobRequirements.TabIndex = 16;
            lblJobRequirements.Text = "Вимоги до роботи:";
            // 
            // lblPhoneOrEmail
            // 
            lblPhoneOrEmail.AutoSize = true;
            lblPhoneOrEmail.Location = new Point(20, 335);
            lblPhoneOrEmail.Name = "lblPhoneOrEmail";
            lblPhoneOrEmail.Size = new Size(98, 15);
            lblPhoneOrEmail.TabIndex = 18;
            lblPhoneOrEmail.Text = "Телефон / Email:";
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(168, 17);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(350, 23);
            txtFullName.TabIndex = 1;
            // 
            // txtProfession
            // 
            txtProfession.Location = new Point(168, 52);
            txtProfession.Name = "txtProfession";
            txtProfession.Size = new Size(350, 23);
            txtProfession.TabIndex = 3;
            // 
            // txtEducation
            // 
            txtEducation.Location = new Point(168, 87);
            txtEducation.Name = "txtEducation";
            txtEducation.Size = new Size(350, 23);
            txtEducation.TabIndex = 5;
            // 
            // txtLastJob
            // 
            txtLastJob.Location = new Point(168, 122);
            txtLastJob.Name = "txtLastJob";
            txtLastJob.Size = new Size(350, 23);
            txtLastJob.TabIndex = 7;
            // 
            // txtReasonForLeaving
            // 
            txtReasonForLeaving.Location = new Point(168, 157);
            txtReasonForLeaving.Name = "txtReasonForLeaving";
            txtReasonForLeaving.Size = new Size(350, 23);
            txtReasonForLeaving.TabIndex = 9;
            // 
            // txtMaritalStatus
            // 
            txtMaritalStatus.Location = new Point(168, 192);
            txtMaritalStatus.Name = "txtMaritalStatus";
            txtMaritalStatus.Size = new Size(350, 23);
            txtMaritalStatus.TabIndex = 11;
            // 
            // txtHousingConditions
            // 
            txtHousingConditions.Location = new Point(168, 227);
            txtHousingConditions.Name = "txtHousingConditions";
            txtHousingConditions.Size = new Size(350, 23);
            txtHousingConditions.TabIndex = 13;
            // 
            // txtContactInfo
            // 
            txtContactInfo.Location = new Point(168, 262);
            txtContactInfo.Name = "txtContactInfo";
            txtContactInfo.Size = new Size(350, 23);
            txtContactInfo.TabIndex = 15;
            // 
            // txtJobRequirements
            // 
            txtJobRequirements.Location = new Point(168, 297);
            txtJobRequirements.Name = "txtJobRequirements";
            txtJobRequirements.Size = new Size(350, 23);
            txtJobRequirements.TabIndex = 17;
            // 
            // txtPhoneOrEmail
            // 
            txtPhoneOrEmail.Location = new Point(168, 332);
            txtPhoneOrEmail.Name = "txtPhoneOrEmail";
            txtPhoneOrEmail.Size = new Size(350, 23);
            txtPhoneOrEmail.TabIndex = 19;
            // 
            // btnSave
            // 
            btnSave.Location = new Point(150, 375);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(100, 30);
            btnSave.TabIndex = 20;
            btnSave.Text = "Зберегти";
            btnSave.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(300, 375);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(100, 30);
            btnCancel.TabIndex = 21;
            btnCancel.Text = "Відмінити";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // WorkerForm
            // 
            ClientSize = new Size(530, 430);
            Controls.Add(lblFullName);
            Controls.Add(txtFullName);
            Controls.Add(lblProfession);
            Controls.Add(txtProfession);
            Controls.Add(lblEducation);
            Controls.Add(txtEducation);
            Controls.Add(lblLastJob);
            Controls.Add(txtLastJob);
            Controls.Add(lblReasonForLeaving);
            Controls.Add(txtReasonForLeaving);
            Controls.Add(lblMaritalStatus);
            Controls.Add(txtMaritalStatus);
            Controls.Add(lblHousingConditions);
            Controls.Add(txtHousingConditions);
            Controls.Add(lblContactInfo);
            Controls.Add(txtContactInfo);
            Controls.Add(lblJobRequirements);
            Controls.Add(txtJobRequirements);
            Controls.Add(lblPhoneOrEmail);
            Controls.Add(txtPhoneOrEmail);
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            Name = "WorkerForm";
            Text = "Додавання анкети працівника";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
